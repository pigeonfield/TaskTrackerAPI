﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaskTrackerAPI.DAL.DAO.Enums
{
    public enum CategoryEnum
    {
        Work = 1,
        Private = 2,
        Travelling = 3,
        Shopping = 4
    }
}
