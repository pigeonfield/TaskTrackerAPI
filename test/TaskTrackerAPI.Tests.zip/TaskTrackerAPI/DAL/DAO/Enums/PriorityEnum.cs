﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaskTrackerAPI.DAL.DAO.Enums
{
    public enum PriorityEnum
    {
        Low = 1,
        Medium = 2,
        High = 3
    }
}
